# NexGo — Reproductor IPTV (M3U)

App Android nativa (Kotlin + Jetpack Compose + Media3/ExoPlayer) que reproduce tu lista M3U/M3U8.
Funciona en **teléfono/tablet Android**, **Android TV / Google TV** y **TV box genéricos** desde el mismo APK.

## Qué incluye

- Pantalla con lista de canales a la izquierda, reproductor grande a la derecha y tabs de categorías arriba (agrupadas por `group-title` de tu M3U).
- Parser M3U/M3U8 propio (`M3UParser.kt`) que lee `#EXTINF`, `tvg-logo` y `group-title`.
- Reproducción de HLS (.m3u8) y otros formatos soportados por Media3/ExoPlayer.
- Guarda la última lista cargada (DataStore) para no tener que reingresarla cada vez.
- Manifest configurado para aparecer tanto en el launcher normal (teléfono) como en la fila de apps de Android TV (`LEANBACK_LAUNCHER`), con banner 320x180 propio.
- Diseño, ícono y nombre 100% propios de "NexGo" (paleta cian/violeta), sin usar marca ni logos de terceros.

## Cómo compilarlo

1. Instala **Android Studio** (versión reciente, Koala o superior).
2. Abre esta carpeta (`NexGo/`) como proyecto: *File → Open*.
3. Android Studio generará automáticamente el Gradle Wrapper la primera vez que sincronices (no incluí el binario `gradle-wrapper.jar` porque este entorno no tiene acceso a internet para descargarlo).
   - Si prefieres hacerlo por línea de comandos, con Gradle instalado localmente corre:
     ```
     gradle wrapper --gradle-version 8.7
     ```
     dentro de la carpeta del proyecto, y luego usa `./gradlew` normalmente.
4. Sincroniza el proyecto (Android Studio te lo pedirá solo).
5. Ejecuta *Build → Generate Signed Bundle / APK* para tu APK firmado, o simplemente dale ▶️ Run para probar en un emulador/dispositivo conectado.

## Cómo generar el APK con GitHub (sin instalar nada en tu computador)

Este proyecto ya incluye un workflow (`.github/workflows/build.yml`) que compila el APK automáticamente en los servidores de GitHub.

1. Crea un repositorio nuevo en [github.com](https://github.com) (puede ser privado), por ejemplo `nexgo-app`.
2. Sube el contenido de esta carpeta al repo. Dos formas:
   - **Por la web**: en la página del repo, botón "Add file → Upload files", arrastra todo el contenido de la carpeta `NexGo/` (incluida la carpeta `.github/`, que suele estar oculta — asegúrate de que se suba) y haz commit.
   - **Por línea de comandos**:
     ```
     cd NexGo
     git init
     git add .
     git commit -m "Primer commit de NexGo"
     git branch -M main
     git remote add origin https://github.com/TU_USUARIO/nexgo-app.git
     git push -u origin main
     ```
3. Ve a la pestaña **Actions** de tu repositorio en GitHub. Debería aparecer un workflow llamado "Build NexGo APK" corriendo automáticamente (tarda 3-5 minutos).
4. Cuando termine (ícono verde ✅), entra a esa ejecución y baja hasta **Artifacts**. Ahí vas a encontrar `NexGo-debug-apk` — descárgalo, es un `.zip` que contiene el `app-debug.apk`.
5. Copia ese `.apk` a tu teléfono, Android TV o TV box e instálalo (activa "orígenes desconocidos" si te lo pide).

> Este workflow genera un APK de **debug**, ideal para probar. Para publicarlo en Play Store necesitarías firmarlo como "release" con tu propia keystore — te puedo ayudar con eso cuando llegues a ese punto.

## Cómo instalar en TV box / Android TV

- El mismo APK sirve para teléfono, Android TV y TV box (no necesitas builds separados).
- Para instalar en un TV box sin Play Store: copia el `.apk` a un USB o usa un instalador de APKs (ej. "Enviar archivos a TV" / ADB).
- Vía ADB (con el TV box en la misma red o por USB):
  ```
  adb connect <IP_DEL_TVBOX>:5555
  adb install app-release.apk
  ```

## Cómo cargar tu lista M3U

1. Abre la app → botón **"Agregar lista M3U"** (arriba a la derecha).
2. Pega la URL de tu lista M3U/M3U8 (la que ya tienes licenciada).
3. Toca **Cargar**. Los canales aparecerán agrupados por categoría según los `group-title` de tu lista.

> Nota legal: esta app solo reproduce el contenido de la URL que tú ingreses. Asegúrate de tener los derechos/licencia correspondientes sobre esa lista y sus canales.

## Estructura del proyecto

```
NexGo/
├── app/
│   ├── build.gradle.kts
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/nexgo/iptv/
│       │   ├── MainActivity.kt          (UI completa en Compose)
│       │   ├── model/Channel.kt
│       │   ├── data/M3UParser.kt
│       │   ├── data/PlaylistRepository.kt
│       │   └── ui/theme/                (colores y tema)
│       └── res/
│           ├── values/ (strings, colores, tema)
│           ├── drawable/ (ícono, banner TV — diseño propio)
│           └── mipmap-anydpi-v26/ (ícono adaptativo)
├── build.gradle.kts
├── settings.gradle.kts
└── gradle.properties
```

## Próximos pasos sugeridos

- Agregar EPG (guía de programación) si tu proveedor M3U la expone (`#EXT-X-*` o XMLTV).
- Favoritos / múltiples listas guardadas.
- Perfil de usuario / control parental.
- Splash screen animado y logo en PNG de alta resolución (los actuales son vectores simples que puedes reemplazar por tu arte final).
